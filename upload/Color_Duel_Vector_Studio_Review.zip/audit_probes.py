"""Non-destructive compiler probes. Usage: python audit_probes.py [repo-root] [output-dir]."""
from pathlib import Path
import sys,json,io,xml.etree.ElementTree as ET
import numpy as np
from PIL import Image
import cairosvg
ROOT=Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).parent/'source'
OUT=Path(sys.argv[2]) if len(sys.argv)>2 else Path(__file__).parent/'reproductions'
OUT.mkdir(parents=True,exist_ok=True)
sys.path.insert(0,str(ROOT/'mini-services/color-duel-studio'))
from studio.svg_master import clean_svg,import_master
from studio.pipeline import compile_svg_master,read_json,load_bundle,edit_bundle
from studio.models import BuildSettings,EditRequest
S=BuildSettings(min_region_pixels=4,min_label_radius=1)
fixtures={
'nested':('<rect width="100" height="100" fill="#0000FF"/><rect x="25" y="25" width="50" height="50" fill="#FF0000"/>',(50,50)),
'stroke':('<rect x="10" y="10" width="80" height="80" fill="#FF0000" stroke="#000000" stroke-width="8"/>',(10,50)),
'fill_opacity':('<rect width="100" height="100" fill="#0000FF"/><rect x="25" y="25" width="50" height="50" fill="#FF0000" fill-opacity="0.5"/>',(50,50)),
'opacity':('<rect width="100" height="100" fill="#0000FF"/><rect x="25" y="25" width="50" height="50" fill="#FF0000" opacity="0.5"/>',(50,50)),
'nonzero':('<path fill="#FF0000" fill-rule="nonzero" d="M10 10 L90 10 L90 90 L10 90 Z M30 30 L70 30 L70 70 L30 70 Z"/>',(50,50)),
'gradient_percent':('<defs><linearGradient id="g" x1="0%" y1="0%" x2="100%" y2="0%"><stop offset="0" stop-color="#FF0000"/><stop offset="1" stop-color="#0000FF"/></linearGradient></defs><rect width="100" height="100" fill="url(#g)"/>',(50,50)),
'gradient_transform':('<defs><linearGradient id="g" gradientUnits="userSpaceOnUse" x1="0" y1="0" x2="100" y2="0" gradientTransform="rotate(90 50 50)"><stop offset="0" stop-color="#FF0000"/><stop offset="1" stop-color="#0000FF"/></linearGradient></defs><rect width="100" height="100" fill="url(#g)"/>',(50,10)),
'ink_z_order':('<path d="M10 50 L90 50" stroke="#000000" stroke-width="8" fill="none"/><rect x="25" y="25" width="50" height="50" fill="#FF0000"/>',(50,50)),
'attribute_escape':('<rect id="probe&quot; data-audit-injected=&quot;yes" width="100" height="100" fill="#FF0000"/>',(50,50)),
}
results={}
for name,(body,point) in fixtures.items():
 d=OUT/name;d.mkdir(exist_ok=True)
 raw='<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100">'+body+'</svg>'
 (d/'original.svg').write_text(raw)
 rec={'sample_point':point}
 try:
  meta=clean_svg(raw.encode(),d/'sanitized.svg')
  rec['sanitize_summary']=meta.get('summary')
  if name=='attribute_escape':
   rec['injected_attribute_survived']=any(e.attrib.get('data-audit-injected')=='yes' for e in ET.fromstring((d/'sanitized.svg').read_text()).iter())
  b=compile_svg_master(d/'sanitized.svg',d/'bundle',artwork_id=name,version='0.1.0',title=name,settings=S)
  rec['validation_passed']=b['validation']['passed'];rec['regions']=b['manifest']['regionCount']
  images={}
  for label,path in [('original',d/'original.svg'),('sanitized',d/'sanitized.svg'),('compiled',d/'bundle/colored.svg')]:
   png=cairosvg.svg2png(url=str(path),output_width=100,output_height=100)
   (d/f'{label}.png').write_bytes(png)
   im=Image.open(io.BytesIO(png)).convert('RGBA');bg=Image.new('RGBA',im.size,'white');bg.alpha_composite(im);a=np.array(bg.convert('RGB'));images[label]=a
   rec[label+'_pixel']=a[point[1],point[0]].tolist()
  rec['original_to_compiled_mean_abs_rgb_diff']=round(float(np.abs(images['original'].astype(float)-images['compiled'].astype(float)).mean()),3)
 except Exception as e:rec['error']=f'{type(e).__name__}: {e}'
 results[name]=rec
# Palette editing is intentionally checked independently from paint regeneration.
d=OUT/'nested/bundle';b=load_bundle(d);r=b['geometry']['regions'][1]
other=next(p['id'] for p in b['palette'] if p['id']!=r['paletteId'])
edit_bundle(d,OUT/'palette-edit',EditRequest(base_revision='probe',action='palette',region_ids=[r['id']],palette_id=other),'0.2.0')
results['palette_edit']={'paint_unchanged':(d/'paint.json').read_bytes()==(OUT/'palette-edit/paint.json').read_bytes(),'colored_svg_unchanged':(d/'colored.svg').read_bytes()==(OUT/'palette-edit/colored.svg').read_bytes(),'old_palette':r['paletteId'],'new_palette':other}
(OUT/'compiler-results.json').write_text(json.dumps(results,indent=2))
print(json.dumps({k:{a:v for a,v in r.items() if a!='sanitize_summary'} for k,r in results.items()},indent=2))
