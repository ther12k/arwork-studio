import fs from 'node:fs';
import path from 'node:path';
const root=path.dirname(new URL(import.meta.url).pathname);
const {validateBundle:oldValidate}=await import('./source/mini-services/color-duel-studio/integration/detailed-board.mjs');
const {validateBundle:currentValidate}=await import('./harness/board.mjs');
const targets={
 'legacy-polygon':'source/mini-services/color-duel-studio/examples/compiled-treehouse',
 'current-native-svg':'source/mini-services/color-duel-studio/workspace/art-9761ab8df8004aa3/revisions/rev-c5f3f1a31d58409c',
 'current-curved-raster':'source/mini-services/color-duel-studio/workspace/art-088a00d04df04086/revisions/rev-1ca34b2b32114056'
};
const results={};
for(const [name,dir] of Object.entries(targets)){
 const [manifest,geometry,palette,paint]=['artwork.json','regions.json','palette.json','paint.json'].map(f=>JSON.parse(fs.readFileSync(path.join(root,dir,f),'utf8')));
 const bundle={manifest,geometry,palette,paint};results[name]={};
 for(const [label,fn] of [['shipped_integration',oldValidate],['current_studio',currentValidate]]){
  try{fn(bundle);results[name][label]='accepted'}catch(e){results[name][label]=e.message}
 }
}
fs.writeFileSync(path.join(root,'reproductions/adapter-results.json'),JSON.stringify(results,null,2));console.log(results);
