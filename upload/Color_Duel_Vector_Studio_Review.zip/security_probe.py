"""Harmless SVG escaping check: toggles a local browser variable; no network/data access."""
from pathlib import Path
import sys,json
from playwright.sync_api import sync_playwright
root=Path(__file__).parent
sys.path.insert(0,str(root/'source/mini-services/color-duel-studio'))
from studio.svg_master import clean_svg
raw='<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><rect id="probe&quot; onmouseover=&quot;window.__studioAuditProbe=1" width="100" height="100" fill="#FF0000"/></svg>'
dest=root/'reproductions/attribute_escape/event-sanitized.svg'
clean_svg(raw.encode(),dest)
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
 page=b.new_page();page.set_content(raw);page.locator('rect').dispatch_event('mouseover');original=page.evaluate('window.__studioAuditProbe === 1')
 page.set_content(dest.read_text());page.locator('path').dispatch_event('mouseover');sanitized=page.evaluate('window.__studioAuditProbe === 1')
 b.close()
r={'original_attribute_executed':original,'sanitized_attribute_executed':sanitized,'context':'SVG rendered as DOM content, not through an img element','effect':'A harmless local window variable was set; no networking or access to user data.'}
(root/'reproductions/security-results.json').write_text(json.dumps(r,indent=2));print(r)
