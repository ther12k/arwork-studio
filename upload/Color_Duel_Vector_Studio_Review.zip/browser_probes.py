"""Browser-level tests of the actual TypeScript VectorBoard, transpiled without changes."""
from pathlib import Path
from playwright.sync_api import sync_playwright
from PIL import Image
import io,json
ROOT=Path(__file__).parent
OUT=ROOT/'reproductions';results={}
TARGETS={
 'nested':'reproductions/nested/bundle',
 'native_svg':'source/mini-services/color-duel-studio/workspace/art-9761ab8df8004aa3/revisions/rev-c5f3f1a31d58409c',
 'curved_raster':'source/mini-services/color-duel-studio/workspace/art-088a00d04df04086/revisions/rev-1ca34b2b32114056',
}
with sync_playwright() as pw:
 browser=pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
 errors=[]
 for name,path in TARGETS.items():
  page=browser.new_page(viewport={'width':1100,'height':850},device_scale_factor=1)
  page.on('pageerror',lambda e:errors.append(str(e)))
  page.set_content('<style>body{margin:20px;font-family:Arial}svg{display:block;width:480px;height:640px;background:white;border:1px solid #bbb}</style><h3>Actual studio renderer — isolated audit harness</h3><svg id="board"></svg>')
  js=(ROOT/'harness/board.mjs').read_text().replace('export ', '')
  page.add_script_tag(content='(()=>{'+js+';window.VectorBoard=VectorBoard;})()')
  bundle={k:json.loads((ROOT/path/f).read_text()) for k,f in [('manifest','artwork.json'),('geometry','regions.json'),('palette','palette.json'),('paint','paint.json')]}
  page.evaluate('''bundle=>{const t=performance.now();window.board=new window.VectorBoard(document.querySelector('svg'),bundle);window.mountMs=performance.now()-t;}''',bundle)
  result=page.evaluate('''() => ({mountMs, state:board.state(),labelOwnerMismatches:[...board.regions].map(([id,r])=>({id,owner:board.hitTest(r.label.x,r.label.y),label:r.label})).filter(r=>r.id!==r.owner)})''')
  result['state']={k:v for k,v in result['state'].items() if k in ['completed','total','zoom']}
  page.locator('svg#board').screenshot(path=str(OUT/f'{name}-numbered.png'))
  if name=='nested':
   result['foregroundPaint']=page.evaluate('''() => {const [id,r]=[...board.regions][1];board.setPalette(r.paletteId);return {id,result:board.paint(id),completed:board.state().completed}}''')
   im=Image.open(io.BytesIO(page.locator('svg#board').screenshot())).convert('RGB')
   sample=page.evaluate('''()=>{const p=new DOMPoint(35,35).matrixTransform(board.svg.getScreenCTM());const r=board.svg.getBoundingClientRect();return [Math.floor(p.x-r.x),Math.floor(p.y-r.y)];}''')
   result['interiorSampleArtPoint']=[35,35]
   result['interiorPixelAfterForegroundFill']=im.getpixel(tuple(sample))
   page.locator('svg#board').screenshot(path=str(OUT/'nested-after-foreground-fill.png'))
   page.evaluate('board.setPreview(true)');im2=Image.open(io.BytesIO(page.locator('svg#board').screenshot())).convert('RGB')
   result['interiorPixelFullyColoredPreview']=im2.getpixel(tuple(sample))
  else:
   page.evaluate('board.setPreview(true)');page.locator('svg#board').screenshot(path=str(OUT/f'{name}-colored.png'))
   # Event-handler cost only. This is not a hardware/mobile frame-rate claim.
   result['hundredSynchronousZoomCallsMs']=page.evaluate('''() => {const t=performance.now();for(let i=0;i<100;i++)board.zoom(i%2?1/1.02:1.02);return performance.now()-t}''')
  results[name]=result
  page.close()
 results['browser']=browser.version;results['consoleErrors']=errors
 browser.close()
(OUT/'browser-results.json').write_text(json.dumps(results,indent=2));print(json.dumps(results,indent=2))
