# Color Duel Vector Studio — review evidence pack

Start with `Vector_Studio_Review.md`. `AGENT_HANDOFF.md` is the implementation brief.
This is a review and regression-evidence pack, not a patched application.

## Contents

- Existing-test output: `pytest.log` (31 passed).
- Strict renderer type-check output: `tsc-renderer.log` (two errors).
- Compiler, adapter, browser and harmless security probe results in `reproductions/`.
- Original/sanitized/compiled SVG and PNG fixture comparisons.
- Actual isolated-renderer screenshots (not full Next.js UI screenshots).
- Probe scripts and `harness/board.mjs`, the uploaded renderer transpiled without application-logic changes.
- Source archive checksum and reviewed inventory. No source archive, account credentials or `.env` files are included.

## Re-running the probes

Keep this pack as a separate audit folder. Place a copy of the original uploaded repository at `source/` inside it, with `source/src/` and `source/mini-services/` present. The adapter/browser probes expect the example and workspace revisions from that original upload. The source is intentionally not duplicated in this small pack.

Use an isolated Python environment with the repository's `mini-services/color-duel-studio/requirements-tested.txt` dependencies plus CairoSVG, Pillow and Playwright as needed. Node.js is required for `adapter_probe.mjs`. Browser probes use `/usr/bin/chromium`; adjust that explicit path to a locally installed Chromium executable. Headless launch flags here are for this disposable review harness, not production-server configuration.

From this pack's directory:

```sh
python audit_probes.py
node adapter_probe.mjs
python browser_probes.py
python security_probe.py
```

These commands overwrite corresponding evidence under `reproductions/`. The included `harness/board.mjs` matches the reviewed snapshot. Regenerate it from `source/src/lib/detailed-board.ts` with TypeScript after modifying the application; otherwise a rerun would test the old renderer. The full Next.js app, external AI APIs and multiplayer game were not exercised.

`security_probe.py` contains a deliberately crafted local SVG fixture that sets only a harmless browser variable on a mouse event. It makes no network calls and accesses no user data. Do not publish the crafted fixture as production artwork.

The schema counts and export-size inventory in `export-metrics.json` are recorded evidence; the four scripts above do not recreate every inventory measurement. See the report for paths, interpretation and limitations.
